package com.rak12.mod3app.model

data class Restaurant(
    var id: Int,
    var name: String,
    val rating: String,
    val cost: String,
    val img: String


)
