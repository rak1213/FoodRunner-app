package com.rak12.mod3app.model

data class RestaurantDescription(
    var id: String,
    var name: String,
    val cost: String,
    val restaurantid: Int
)
