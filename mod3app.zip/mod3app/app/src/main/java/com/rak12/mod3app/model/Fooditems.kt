package com.rak12.mod3app.model

class Fooditems(
    val foodid: String,
    val food_name: String,
    val food_cost: String
)